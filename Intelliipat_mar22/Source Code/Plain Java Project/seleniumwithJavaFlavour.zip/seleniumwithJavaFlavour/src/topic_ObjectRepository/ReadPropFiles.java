package topic_ObjectRepository;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.testng.annotations.Test;

public class ReadPropFiles {
	
	static WebDriver driver;
	@Test
	public void dummyGmail() throws IOException, InterruptedException
	{
		//import from 
		Properties prop=new Properties();
		FileInputStream ip=new FileInputStream("D:/March22nd_2020/seleniumwithJavaFlavour/src/topic_ObjectRepository/cofig.properties");
	
		prop.load(ip);
		System.out.println("name");
		//Name
		String Name=prop.getProperty("name");
		System.out.println(Name);
		//AGE
		String AGE=prop.getProperty("age");
		System.out.println(AGE);
		
		//URL
		String URL=prop.getProperty("url");
		System.out.println(URL);
		//For Browser
		String BrowserName=prop.getProperty("browser");
		System.out.println(BrowserName);
		
		if(BrowserName.equals("chrome"))
		{
			//Launch Chrome Browser 
			System.setProperty("webdriver.chrome.driver","D:\\March22nd_2020\\chromedriver.exe");
			//Humanbeing sai=new Humanbeing();
			 driver=new ChromeDriver();
			 System.out.println("Google Chrome Browser");
		}
		else if(BrowserName.equals("firefox"))
		{
			//Launch Chrome Browser 
			System.setProperty("webdriver.gecko.driver","D:\\March22nd_2020\\geckodriver.exe");
			//Humanbeing sai=new Humanbeing();
			 driver=new FirefoxDriver();
			 System.out.println("FirefoxBrowser");
		}
		else if(BrowserName.equals("IE"))
		{
			//Launch IE Browser
			System.setProperty("webdriver.ie.driver","D:\\March22nd_2020\\IEDriverServer.exe");
		driver=new InternetExplorerDriver();
			 System.out.println("IE Browser");
		}
		
		driver.get(URL);
		Thread.sleep(5000);
		//Enter UserName into TextBox
		driver.findElement(By.xpath(prop.getProperty("UserNameField"))).sendKeys(prop.getProperty("username"));
		Thread.sleep(5000);
		driver.findElement(By.xpath(prop.getProperty("MovetoNext"))).click();
		Thread.sleep(5000);
		driver.findElement(By.xpath(prop.getProperty("PwdField"))).sendKeys(prop.getProperty("password"));
		Thread.sleep(5000);
		driver.findElement(By.xpath(prop.getProperty("MovetoNext"))).click();
		Thread.sleep(5000);
		
	
		
		driver.close();

		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
