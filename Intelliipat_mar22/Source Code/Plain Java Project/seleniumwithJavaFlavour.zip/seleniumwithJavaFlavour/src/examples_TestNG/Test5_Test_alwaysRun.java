package examples_TestNG;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

public class Test5_Test_alwaysRun {
	
public WebDriver driver;	
	
	@Test(priority=1)
	public void launchBrowser()
	{
//Lauch Chrome Browser
		System.setProperty("webdriver.chrome.driver","D:\\March22nd_2020\\chromedriver.exe");
		 driver=new ChromeDriver();
		
	}
	
	
	
	@Test(priority=2)
	public void passURL()
	{
	
//	Goto Test URL https://www.facebook.com
		driver.get("https://www.facebook.com");
	}
	
	@Test(priority=3)
	public void waitTime()
	{
	
//	Wait for 5  sec
		 driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS);
		 
	}
	
	@Test(priority=4)
	
public void verifyFacebookTitle()
{
//Verify Title of Page 		
	String atitle=driver.getTitle();
	System.out.println(atitle);
	String ExpTtitle="Sai-Facebook � log in or sign up";



	
Assert.assertEquals(atitle, ExpTtitle);	
	
}

//Close Browser	
	   @Test(dependsOnMethods="verifyFacebookTitle",alwaysRun=true)
	   
		public void teardown()
		{

	     driver.close();		
		}
		

	
 
	
}
