package examples_TestNG;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class Test2_TestMultipleMethods {
	
public WebDriver driver;	
/*	TestScenario-3
	------------
	Lauch Chrome Browser
	Goto Test URL https://www.facebook.com
	Wait for 5  sec
	Verify Title of Page 
	Close Browser
	=========
	Teast data
	---------
	https://www.bhanusaii.wordpress.com
	Expected Title
	Facebook � log in or sign up
	Actual Title
*/
	
	@Test
	public void alaunch()
	{
//Lauch Chrome Browser
		System.setProperty("webdriver.chrome.driver","D:\\March22nd_2020\\chromedriver.exe");
		 driver=new ChromeDriver();
		
	}
	
	
	
	@Test
	public void bpassURL()
	{
	
//	Goto Test URL https://www.facebook.com
		driver.get("https://www.facebook.com");
	}
	
	@Test
	public void cwaitTime()
	{
	
//	Wait for 5  sec
		 driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS);
		 
	}
	
	@Test
	public void dverifyFacebookTitle()
	{
//Verify Title of Page 		
		String atitle=driver.getTitle();
		System.out.println(atitle);


		if(atitle.equals("Sai-Facebook � log in or sign up"))
		{
			System.out.println("Facebook Launches-Test Passed");
		}
		else
		{
			System.out.println("Not Launched Facebook-Test Failed");
		}
	}
	
    @Test 	
	public void eteartdown()
	{
//	Close Browser
     driver.close();		
	}
	
	
}
