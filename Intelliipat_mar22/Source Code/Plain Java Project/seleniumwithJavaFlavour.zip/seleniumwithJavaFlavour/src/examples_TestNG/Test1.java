package examples_TestNG;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Test1 {

	public static void main(String[] args) throws InterruptedException {
		//Launch Chrome Browser
		System.setProperty("webdriver.chrome.driver","D:\\March22nd_2020\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		//Pass the Test URL
		driver.get("https://www.facebook.com");
		//Wait for 5  sec
       Thread.sleep(5000);

//Verify Title of Page 
		
		
String atitle=driver.getTitle();
System.out.println(atitle);


if(atitle.equals("Facebook � log in or sign up"))
{
	System.out.println("Facebook Launches-Test Passed");
}
else
{
	System.out.println("Not Launched Facebook-Test Failed");
}






driver.close();



	}

}
