package webdriver_Commands;

import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Test5_HndlingWindows {

	public static void main(String[] args) throws InterruptedException  {
		//Launch Chrome Browser
		System.setProperty("webdriver.chrome.driver","D:\\Intellipaat_March22nd_2020\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		//Navigate to Test URL
		driver.get("https://www.w3schools.com/jsref/tryit.asp?filename=tryjsref_win_open3");
		//add wait Time  5sec 
		Thread.sleep(5000);
		
	//Click on Tyr it button
						
						driver.switchTo().frame(1);
		
						driver.findElement(By.xpath("//button[text()='Try it']")).click();
						Thread.sleep(5000);	
						
						//Handle Window
						ArrayList<String> wins=new ArrayList<String>(driver.getWindowHandles());
						System.out.println(wins);
						Thread.sleep(5000);	
						
						driver.manage().window().maximize();
					
						
						
			//close the browser
						driver.quit();
						
						
						
						
						
						
						
						
						
				
				
				
				
				
				
				
		
		
		
		
		
		  
		
		
		

	}

}
