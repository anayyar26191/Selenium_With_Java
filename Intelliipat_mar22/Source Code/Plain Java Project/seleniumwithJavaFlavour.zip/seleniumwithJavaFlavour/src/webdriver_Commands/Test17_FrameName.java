package webdriver_Commands;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Test17_FrameName {

	public static void main(String[] args) throws InterruptedException {
		// Launch Chrome Browser
		System.setProperty("webdriver.chrome.driver","D:\\March22nd_2020\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		
		//Goto Test URL  https://www.selenium.dev/selenium/docs/api/java/
		driver.get("https://www.selenium.dev/selenium/docs/api/java/");
		
		
		//Wait time for 5 Sec
		Thread.sleep(5000);
		
		//To Switch to  0th Frame need to specify the Index of Frame
		driver.switchTo().frame("packageListFrame");
	
		//click on link Text com.thoughtworks.selenium
		driver.findElement(By.linkText("com.thoughtworks.selenium")).click();
		//driver.findElement(By.xpath("//a[text()='com.thoughtworks.selenium']")).click();
		
		//Wait time for 5 Sec
				Thread.sleep(7000);
				//To Switch from 0th Frame  to the 1st Frame,before that need to switch to Default content
				driver.switchTo().defaultContent();
				driver.switchTo().frame("packageFrame");
		
				//click on linktext CommandProcessor which is inside 1st Frame
				driver.findElement(By.xpath("//span[text()='CommandProcessor']")).click();
				
				
				//Wait time for 5 Sec
				Thread.sleep(5000);
				
				
				//To switch from 1st frame to 2nd frame,before that need to switch to Default content
				driver.switchTo().defaultContent();
				
				//click on linktext Tree  which is inside 2nd Frame
				
				driver.switchTo().frame("classFrame");
				driver.findElement(By.xpath("(//a[text()='Tree'])[1]")).click();
				
				//Wait time for 5 Sec
				Thread.sleep(8000);
				
				
				//close the browser
				driver.close();
		
		
	
		
		 
		

	}

}
