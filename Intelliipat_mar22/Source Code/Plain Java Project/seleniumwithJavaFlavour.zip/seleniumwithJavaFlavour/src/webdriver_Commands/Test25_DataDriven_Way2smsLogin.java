package webdriver_Commands;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;
import jxl.write.biff.RowsExceededException;

public class Test25_DataDriven_Way2smsLogin {

	public static void main(String[] args) throws InterruptedException, BiffException, IOException, RowsExceededException, WriteException {
		
//Open the Excel File for Read andWrite ,which is placed inside the same package 
//import from java io package
		File f=new File("D:\\March22nd_2020\\seleniumwithJavaFlavour\\src\\webdriver_Commands\\TestData_sms4india.xls");
//Read Operation 
		Workbook readwb=Workbook.getWorkbook(f);
        Sheet readsht=readwb.getSheet(0); //0 means Sheet1
        System.out.println(readsht);
        
        int numberofr=readsht.getRows();
        System.out.println(numberofr);
        
//Open Excel Sheet for Write 
        WritableWorkbook wwb=Workbook.createWorkbook(f,readwb);
        WritableSheet wsh=wwb.getSheet(0);//0 means Sheet1
        
        for(int i=1;i<numberofr;i++)
        {
        	String x=readsht.getCell(0,i).getContents(); //For Phone No
        	String y=readsht.getCell(1,i).getContents(); //For Password 
        	
        	
        	// Launch Firefox Browser
   		 System.setProperty("webdriver.chrome.driver","D:\\March22nd_2020\\chromedriver.exe");
   		 WebDriver driver=new ChromeDriver();
   		 
   		 //Goto Test URL 
   		 driver.get("https://www.sms4india.com/");
   		 
   		 //WaitTime
            Thread.sleep(5000);
            driver.manage().window().maximize();
            
            //Enter Mobile number
            driver.findElement(By.xpath("(//input[@name='mobileNo'])[1]")).sendKeys(x);
            Thread.sleep(5000);
            //Enter Password
            driver.findElement(By.xpath("(//input[@id='password'])[1]")).sendKeys(y);
            Thread.sleep(5000);
            //Click Login
            driver.findElement(By.xpath("(//button)[5]")).click(); 
            Thread.sleep(5000);
           //Verification Point
            String ExpURL="https://www.sms4india.com/send-sms";
            String ActURL=driver.getCurrentUrl();
            System.out.println(ActURL);
            if(ExpURL.equals(ActURL))
            {
            	  System.out.println("Login Sucess-Test Passed");
            	  Label l=new Label(2,i,"Test Passed");  //import Label calss from JXL Write
            	  wsh.addCell(l);
            }
            else
            {
            	 System.out.println("Login Faield-Test Failed");
           	  Label l=new Label(2,i,"Test Failed");  //import Label class from JXL Write
           	  wsh.addCell(l);
            }
            
            
          
            //close browser
            driver.close();
        }
        wwb.write(); //To save in Excel
        wwb.close();
        readwb.close();


	}

}
