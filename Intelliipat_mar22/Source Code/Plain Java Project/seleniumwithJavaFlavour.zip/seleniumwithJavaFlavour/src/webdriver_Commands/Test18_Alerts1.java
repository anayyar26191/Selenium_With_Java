package webdriver_Commands;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Test18_Alerts1 {

	public static void main(String[] args) throws InterruptedException {
		// Launch Firefox Browser
		 System.setProperty("webdriver.gecko.driver","D:\\March22nd_2020\\geckodriver.exe");
		 WebDriver driver=new FirefoxDriver();
		 
		 //Goto Test URL 
		 driver.get("https://www.jquery-az.com/javascript/demo.php?ex=151.1_1");
		 
		 
		 
		 //WaitTime
         Thread.sleep(5000);	
         
         //click on button click here..........
         driver.findElement(By.xpath("//button[starts-with(text(),'Click here')]")).click();
         
       //WaitTime
         Thread.sleep(5000);	
         
         //Handle Alert
        String x= driver.switchTo().alert().getText();
        System.out.println(x);
        
        if(x.contains("Are you sure you"))
        {
        	System.out.println("Valid Alert Generated -Test Passed");
        }
        else
        {
        	System.out.println("InValid Alert Generated -Test Failed");
        }
        //WaitTime
        Thread.sleep(5000);	
           
        driver.switchTo().alert().dismiss();
        
        //WaitTime
        Thread.sleep(5000);	

       String y= driver.switchTo().alert().getText();
       System.out.println(y);
       driver.switchTo().alert().accept();
        
       //WaitTime
       Thread.sleep(5000);	
       driver.close();
        
        
        
         
         

	}

}
