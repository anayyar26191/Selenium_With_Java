package webdriver_Commands;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Test10_Facebook_Registartion {

	public static void main(String[] args) throws InterruptedException {
		//Launch Chrome Browser 
		System.setProperty("webdriver.chrome.driver","D:\\Intellipaat_March22nd_2020\\chromedriver.exe");
		WebDriver dchrome=new ChromeDriver();
		
		//Pass the Test URL into Chroem Browser  https://www.facebook.com/
		
		dchrome.get("https://www.facebook.com/");
		

		dchrome.manage().window().maximize();
		
		//Add wait Time for 5 Sec
				Thread.sleep(3000);
				
		//Fill the FirstName  Text Box 
				
				dchrome.findElement(By.name("firstname")).sendKeys("Bhanu");
				//Add wait Time for 5 Sec
				Thread.sleep(3000);
				
		//Fill the Surname  Text Box 		
		  //dchrome.findElement(By.name("lastname")).sendKeys("Sai");
		    
		   dchrome.findElement(By.id("u_0_o")).sendKeys("Sai");
		  //Add wait Time for 5 Sec
			Thread.sleep(3000);
			
			dchrome.findElement(By.name("reg_email__")).sendKeys("9999999999");
			
			 //Add wait Time for 5 Sec
			Thread.sleep(3000);
			
			dchrome.findElement(By.name("reg_passwd__")).sendKeys("abc@123456");
			
			
			 //Add wait Time for 5 Sec
			Thread.sleep(3000);
			
			//Select date from Dropdown 
			//Select class is used to select an item from dropdown
			
			Select day=new Select(dchrome.findElement(By.name("birthday_day")));
			day.selectByValue("14");
			 //Add wait Time for 5 Sec
			Thread.sleep(3000);
			
			
			Select month=new Select(dchrome.findElement(By.id("month")));
			month.selectByValue("1");
			 //Add wait Time for 5 Sec
			Thread.sleep(3000);
			
			Select year=new Select(dchrome.findElement(By.name("birthday_year")));
			year.selectByValue("1990");
			 //Add wait Time for 5 Sec
			Thread.sleep(5000);
			dchrome.findElement(By.id("u_0_7")).click();
			
			 //Add wait Time for 5 Sec
			Thread.sleep(5000);
			
			dchrome.findElement(By.name("websubmit")).click();
			
			 //Add wait Time for 5 Sec
			Thread.sleep(5000);
			
			dchrome.close();
			
			
			
		

	}

}
