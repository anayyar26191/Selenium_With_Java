package webdriver_Commands;


import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class Test26_Action_Ex1_CoordinatePoints {

	public static void main(String[] args) throws InterruptedException {
	//Launch Chrome Browser 
		System.setProperty("webdriver.chrome.driver","D:\\March22nd_2020\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		
		driver.get("https://www.flipkart.com/");
		
		Thread.sleep(7000);
		//maximize the window
		driver.manage().window().maximize();
		
		driver.findElement(By.xpath("(//span[text()='Login'])[2]/preceding::*[21]")).click();
		Thread.sleep(5000);
		//Move mouse towards Men
		WebElement e=driver.findElement(By.xpath("//span[text()='Women']"));
		int x=e.getLocation().getX();
		System.out.println(x);
		int y=e.getLocation().getY();
		System.out.println(y);
		Actions a=new Actions(driver);
		a.moveByOffset(x,y).build().perform();
		
		Thread.sleep(6000);
		driver.findElement(By.xpath("(//a[text()='Sarees'])[1]")).click();
		Thread.sleep(5000);
	
		
		
		driver.close();
		
		
	
	}

}
