package webdriver_Commands;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Test20_OtherMethods {

	public static void main(String[] args) throws InterruptedException {
		//Launch Chrome Browser
		System.setProperty("webdriver.chrome.driver","D:\\March22nd_2020\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		//Pass the Test URL
		driver.get("https://www.gmail.com");
		
		Thread.sleep(5000);
		
		
		//Fill User name TextBox
		WebElement e=driver.findElement(By.xpath("//input[@id='identifierId']"));
		
		e.sendKeys("abc@gmail.com");
		Thread.sleep(5000);
		e.clear();
		Thread.sleep(5000);
		e.sendKeys("abcedfsgf@gmail.com");
		Thread.sleep(5000);
		//getAttribute
		String x=e.getAttribute("value");
		System.out.println(x);
		String y=e.getAttribute("id");
		System.out.println(y);
		Thread.sleep(5000);
	//getText()
		String x1=driver.findElement(By.xpath("//input[@name='identifier']/preceding::*[2]")).getText();
		System.out.println(x1);
		Thread.sleep(5000);
	//getCssValue()
		System.out.println("color="+e.getCssValue("color"));
		System.out.println("font-size="+e.getCssValue("font-size"));
		Thread.sleep(5000);
		driver.close();
		
	}

}
