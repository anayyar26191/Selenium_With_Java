package webdriver_Commands;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Test13_absolXpath {

	public static void main(String[] args) throws InterruptedException {
	//Launch Chrome Browser 
		System.setProperty("webdriver.chrome.driver","D:\\Intellipaat_March22nd_2020\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		
		driver.get("https://www.gmail.com");
		
		//Wait for 5 sec
		Thread.sleep(2000);
		
		driver.manage().window().maximize();
		//Wait for 5 sec
		Thread.sleep(5000);
		
		
				
				//driver.findElement(By.id("identifierId")).sendKeys("abcdef@gmail.com");
		driver.findElement(By.xpath("/html[1]/body[1]/div[1]/div[1]/div[2]/div[1]/div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/form[1]/span[1]/section[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/input[1]")).sendKeys("abc@gmail.com");
				//Wait for 5 sec
				Thread.sleep(5000);
				
				
				//driver.findElement(By.className("RveJvd snByac")).click();
				
				driver.findElement(By.xpath("/html[1]/body[1]/div[1]/div[1]/div[2]/div[1]/div[2]/div[1]/div[1]/div[2]/div[1]/div[2]/div[1]/div[1]/div[1]/span[1]/span[1]")).click();
				
				//Wait for 5 sec
				Thread.sleep(5000);
				
				driver.close();
				
	}

}
