package webdriver_Commands;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;


public class Test2_Firefox {

	public static void main(String[] args) throws InterruptedException {
	//Launch Chrome Browser 
		System.setProperty("webdriver.gecko.driver","D:\\Intellipaat_March22nd_2020\\geckodriver.exe");
		//Humanbeing sai=new Humanbeing();
		WebDriver ffdriver=new FirefoxDriver();
		
	//Navigate to https://www.facebook.com
		//get() is amethod part of SWD used to Pass the URL into Browser 
		ffdriver.get("https://www.facebook.com");
		
	//Wait for 5 sec  1 sec 1000ms 
		Thread.sleep(5000);
		
		//Get the Title of a Page  
		// getTtile() used to get the Title of active Page on Current Browser window 
		String titleofPage=ffdriver.getTitle();
		System.out.println(titleofPage);
		
	/*	close the browse
		close() part of SWD  used to close the active browser window*/
		ffdriver.close();
		
	
		

	}

}
