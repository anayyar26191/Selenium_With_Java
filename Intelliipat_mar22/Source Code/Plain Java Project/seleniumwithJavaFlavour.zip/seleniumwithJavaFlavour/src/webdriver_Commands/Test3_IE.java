package webdriver_Commands;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

public class Test3_IE {

	public static void main(String[] args) throws InterruptedException {
		//Launch IE Browser
		System.setProperty("webdriver.ie.driver","D:\\Intellipaat_March22nd_2020\\IEDriverServer.exe");
		WebDriver iedriver=new InternetExplorerDriver();
		//Naviagte to Test URL
		iedriver.get("https://www.facebook.com");
		//Wait for 5 Sec 5000ms
		Thread.sleep(5000);
		//get the Title of Page
	String titleofPage=iedriver.getTitle();
		System.out.println(titleofPage);
		
	//close Browser
		iedriver.quit();
		
		
		
		
		

	}

}
