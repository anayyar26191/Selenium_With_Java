package webdriver_Commands;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Test15_tagname {

	public static void main(String[] args) throws InterruptedException {
		//Launch Chrome Browser
		System.setProperty("webdriver.chrome.driver","D:\\Intellipaat_March22nd_2020\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		//Pass the Test URL
		driver.get("https://www.google.com");
		Thread.sleep(5000);
		//import List Class from  util.List
		List<WebElement> e=driver.findElements(By.tagName("a"));
		System.out.println(e.size());
		
		for(int i=0;i<e.size();i=i+1)
		{
			System.out.println(e.get(i).getText());
			
		}
		
		
		driver.close();
		
	}

}
