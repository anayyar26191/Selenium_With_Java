package webdriver_Commands;

import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Test7_HndlingTabs {

	public static void main(String[] args) throws InterruptedException  {
		//Launch Chrome Browser
		System.setProperty("webdriver.chrome.driver","D:\\Intellipaat_March22nd_2020\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		//Navigate to Test URL
		driver.get("https://bhanusaii.wordpress.com/");
		//add wait Time  5sec 
		Thread.sleep(5000);
		
	//Click on Tyr it button
					
		
						driver.findElement(By.xpath("//a[text()='SELENIUM QUIZ-1']")).click();
						Thread.sleep(5000);	
						
					
						
						//Handle Window
						ArrayList<String> wins=new ArrayList<String>(driver.getWindowHandles());
						System.out.println(wins);
						Thread.sleep(5000);	
						
						//switch from 0th window to 1st window
						driver.switchTo().window(wins.get(1)); //2nd Window in Browser
						
						Thread.sleep(5000);
						
						driver.switchTo().window(wins.get(0)); //2nd Window in Browser
						
						Thread.sleep(5000);	
						
						driver.quit();
						
						
						
						
						
						
						
						
						
				
				
				
				
				
				
				
		
		
		
		
		
		  
		
		
		

	}

}
