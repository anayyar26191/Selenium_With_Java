package webdriver_Commands;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Test19_VerificationPoint4_Gmail {

	public static void main(String[] args) throws InterruptedException {
		//Launch Chrome Browser
		System.setProperty("webdriver.chrome.driver","D:\\March22nd_2020\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		//Pass the Test URL
		driver.get("https://www.gmail.com");
		
		Thread.sleep(5000);
		
		
		//Fill User name TextBox
		driver.findElement(By.xpath("//input[@id='identifierId']")).sendKeys("abc@gmail.com");
		
		//To clear the text from TextBox use clear()
				driver.findElement(By.xpath("//input[@id='identifierId']")).clear();
				
		//Fill User name TextBox		
				driver.findElement(By.xpath("//input[@id='identifierId']")).sendKeys("selenium6river@gmail.com");
				Thread.sleep(5000);
		
		//Click on Next Button
		
		driver.findElement(By.xpath("//span[text()='Next']")).click();
		Thread.sleep(6000);
		
		//Fill Password  TextBox
		driver.findElement(By.xpath("//input[@name='password']")).sendKeys("JavaPythonRocks");
		
		Thread.sleep(7000);
		
		//Click on Next Button
		
				driver.findElement(By.xpath("//span[text()='Next']")).click();
		
		
		
				Thread.sleep(10000);
				
				
				
		String acturl=driver.getCurrentUrl();
		System.out.println(acturl);
		
		//Expexted URL https://mail.google.com/mail/u/0/#inbox
	
		if(acturl.contains("https://mail.google.com/mail/u"))
		{
			System.out.println("Gmail Login Sucess-Test Passed");
		}
		else
		{
			System.out.println("Gmail Login Failed-Test Failed");
		}
		
		
		
		
		
		
		driver.close();
		
	}

}
