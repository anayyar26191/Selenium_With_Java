package webdriver_Commands;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Test4_BrowserAutomation {

	public static void main(String[] args) throws InterruptedException  {
		//Launch Chrome Browser
		System.setProperty("webdriver.chrome.driver","D:\\Intellipaat_March22nd_2020\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		//Navigate to Test URL
		driver.get("https://www.google.com");
		/*Maximize the browser Window If it is in minimized mode maximize it
		  If window is in Maximize mode make it minimize*/
		driver.manage().window().maximize();
		//add wait Time  5sec 
		Thread.sleep(5000);
		//Get the Current URL of Page
		String x=driver.getCurrentUrl();
		System.out.println(x);
		
		
	//Navigate to https://www.w3schools.com/jsref/tryit.asp?filename=tryjsref_win_open3
		driver.navigate().to(" https://www.w3schools.com/code/tryit.asp?filename=GDRFCG8F7T7V");
		//add wait Time  5sec 
		Thread.sleep(5000);
				
	  //Get the Current URL of Page
				String y=driver.getCurrentUrl();
				System.out.println(y);	
				
	//Navigate back to the base url
				driver.navigate().back();
				//add wait Time  5sec 
				Thread.sleep(5000);
						
    //Get the Current URL of Page
						String z=driver.getCurrentUrl();
						System.out.println(z);	
						
  //Navigate to  https://www.w3schools.com/code/tryit.asp?filename=GDRFCG8F7T7V	
						
						driver.navigate().forward();
						//add wait Time  5sec 
						Thread.sleep(5000);
					    //Get the Current URL of Page
						String p=driver.getCurrentUrl();
						System.out.println(p);	
	//Refresh theCurrent Page
						driver.navigate().refresh();
						//add wait Time  5sec 
						Thread.sleep(5000);
					    //Get the Current URL of Page
						String q=driver.getCurrentUrl();
						System.out.println(q);	
	
						
						//Click on Tyr it button
						
						driver.switchTo().frame(1);
						
						driver.findElement(By.xpath("//button[text()='Try it']")).click();
						
						
			//close the browser
						driver.close();
						
						
						
						
						
						
						
						
						
				
				
				
				
				
				
				
		
		
		
		
		
		  
		
		
		

	}

}
