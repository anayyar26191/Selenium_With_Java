package webdriver_Commands;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Test1_Chrome {

	public static void main(String[] args) throws InterruptedException {
	//Launch Chrome Browser 
		System.setProperty("webdriver.chrome.driver","D:\\Intellipaat_March22nd_2020\\chromedriver.exe");
		//Humanbeing sai=new Humanbeing();
		WebDriver chromeBrowser=new ChromeDriver();
		
	//Navigate to https://www.facebook.com
		//get() is amethod part of SWD used to Pass the URL into Browser 
		chromeBrowser.get("https://www.facebook.com");
		
		
	
		
	//Wait for 5 sec  1 sec 1000ms 
		Thread.sleep(5000);
		
		//Get the Title of a Page  
		// getTtile() used to get the Title of active Page on Current Browser window 
		String titleofPage=chromeBrowser.getTitle();
		System.out.println(titleofPage);
		
	/*	close the browse
		close() part of SWD  used to close the active browser window*/
		chromeBrowser.close();
		
	
		

	}

}
