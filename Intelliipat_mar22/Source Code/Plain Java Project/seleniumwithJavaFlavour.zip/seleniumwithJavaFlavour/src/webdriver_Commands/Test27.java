package webdriver_Commands;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Test27 
{
	public static void main(String[] args) throws InterruptedException, AWTException 
	{
		//Launch gmail site
		System.setProperty("webdriver.chrome.driver",
		           "D:\\March22nd_2020\\chromedriver.exe");       
		WebDriver driver=new ChromeDriver();
		driver.get("http://www.gmail.com");
		Thread.sleep(5000);
		//Do login
		driver.findElement(By.name("Email")).sendKeys("vikranthkakarla");
		driver.findElement(By.id("next")).click();
		Thread.sleep(5000);
		driver.findElement(By.name("Passwd")).sendKeys("@CXJPK8626E#");
		driver.findElement(By.id("signIn")).click();
		Thread.sleep(5000);
		//Click compose
		driver.findElement(By.xpath("//*[text()='COMPOSE']")).click();
		Thread.sleep(5000);
		//Fill fields
		driver.findElement(By.name("to"))
						.sendKeys("apj@abdulkalam.com");
		driver.findElement(By.name("subjectbox"))
						.sendKeys("wishes");
		driver.findElement(
			By.xpath("//div[@aria-label='Message Body']"))
			.sendKeys("Hi sir,",Keys.ENTER,
			"How are you in heven?",Keys.ENTER,
			"Regards:",Keys.ENTER,"vikranth");
		driver.findElement(By.xpath(
		"//*[@data-tooltip='Attach files']/descendant::*[3]"
				)).click();
		Thread.sleep(5000);
		//Handle file upload pop-up window
		StringSelection s=new StringSelection(
			"C:\\Users\\Public\\Pictures\\Sample Pictures\\tulips.jpg");
		Toolkit.getDefaultToolkit().getSystemClipboard()
								.setContents(s,null);
		Robot r=new Robot();
		if(System.getProperty("os.name").contains("Windows"))
		{
			r.keyPress(KeyEvent.VK_CONTROL);
			r.keyPress(KeyEvent.VK_V);
			r.keyRelease(KeyEvent.VK_V);
			r.keyRelease(KeyEvent.VK_CONTROL);
			Thread.sleep(5000);
		}
		else if(System.getProperty("os.name").contains("Mac"))
		{
			r.keyPress(KeyEvent.VK_META);
			r.keyPress(KeyEvent.VK_V);
			r.keyRelease(KeyEvent.VK_V);
			r.keyRelease(KeyEvent.VK_META);
			Thread.sleep(5000);
			
		}
		else if(System.getProperty("os.name").contains("Linux"))
		{
			r.keyPress(KeyEvent.VK_CONTROL);
			r.keyPress(KeyEvent.VK_V);
			r.keyRelease(KeyEvent.VK_V);
			r.keyRelease(KeyEvent.VK_CONTROL);
			Thread.sleep(5000);
		}
		else
		{
			System.out.println("Unknown platform");
			System.exit(0); //force stop
		}
		r.keyPress(KeyEvent.VK_ENTER);
		r.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(20000); //for file uploading
		//Click send
		driver.findElement(By.xpath("//*[text()='Send']"))
												.click();
		Thread.sleep(5000);
		String x=driver.findElement(By.xpath(
		  "//*[@role='alert']/descendant::*[3]")).getText();
		System.out.println(x);
		//Do logout
		driver.findElement(By.xpath(
		 "//*[starts-with(@title,'Google Acc')]/child::*"))
												.click();
		Thread.sleep(5000);
		driver.findElement(By.linkText("Sign out")).click();
		Thread.sleep(5000);
		//Close site
		driver.close();
	}

}




