package webdriver_Commands;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Test12 {

	public static void main(String[] args) throws InterruptedException {
	//Launch Chrome Browser 
		System.setProperty("webdriver.chrome.driver","D:\\Intellipaat_March22nd_2020\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		
		driver.get("https://www.gmail.com");
		
		//Wait for 5 sec
		Thread.sleep(2000);
		
		driver.manage().window().maximize();
		//Wait for 5 sec
		Thread.sleep(5000);
		
		
				
				driver.findElement(By.id("identifierId")).sendKeys("abcdef@gmail.com");
				//Wait for 5 sec
				Thread.sleep(5000);
				
				
				driver.findElement(By.className("RveJvd snByac")).click();
				
				//Wait for 5 sec
				Thread.sleep(5000);
				
				driver.close();
				
	}

}
