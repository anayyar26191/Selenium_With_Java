package webdriver_Commands;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Test24_Jrt_Notepad {

	public static void main(String[] args) throws InterruptedException, IOException, AWTException {
	
		Runtime.getRuntime().exec("notepad.exe");
		Thread.sleep(5000);
		Robot r=new Robot();
		
		r.keyPress(KeyEvent.VK_B);
		r.keyPress(KeyEvent.VK_H);
		r.keyPress(KeyEvent.VK_A);
		r.keyPress(KeyEvent.VK_N);
		r.keyPress(KeyEvent.VK_U);
		
		Thread.sleep(5000);
		//Close NotePad
		r.keyPress(KeyEvent.VK_ALT);
		r.keyRelease(KeyEvent.VK_ALT);
		r.keyPress(KeyEvent.VK_F4);
		r.keyRelease(KeyEvent.VK_F4);
		
		
		
		
		
		
	
		

	}

}
