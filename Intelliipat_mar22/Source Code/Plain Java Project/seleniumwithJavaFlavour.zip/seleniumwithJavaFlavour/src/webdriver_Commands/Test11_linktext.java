package webdriver_Commands;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Test11_linktext {

	public static void main(String[] args) throws InterruptedException {
	//Launch Chrome Browser 
		System.setProperty("webdriver.chrome.driver","D:\\March22nd_2020\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		
		driver.get("https://www.google.com");
		
		//Wait for 5 sec
		Thread.sleep(2000);
		
		driver.manage().window().maximize();
		//Wait for 5 sec
		Thread.sleep(5000);
		
		//Click on Gmail Link Text
		driver.findElement(By.linkText("Gmail")).click();
		//Wait for 7 sec
				Thread.sleep(7000);
				
				
				
				driver.close();
				
	}

}
