package webdriver_Commands;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Test18_Alerts2 {

	public static void main(String[] args) throws InterruptedException {
		// Launch Firefox Browser
		 System.setProperty("webdriver.gecko.driver","D:\\March22nd_2020\\geckodriver.exe");
		 WebDriver driver=new FirefoxDriver();
		 
		 //Goto Test URL 
		 driver.get("https://www.w3schools.com/js/tryit.asp?filename=tryjs_prompt");
		 
		 
		 
		 //WaitTime
         Thread.sleep(5000);	
         driver.switchTo().frame("iframeResult");
         
         
         //click on button click here..........
         driver.findElement(By.xpath("//button[text()='Try it']")).click();
         
       //WaitTime
         Thread.sleep(5000);	
         
         //Handle Alert
         driver.switchTo().alert().sendKeys("Harsha ");
//        //WaitTime
        Thread.sleep(5000);	
           
        driver.switchTo().alert().accept();
        
        //WaitTime
        Thread.sleep(5000);	

       	
       driver.close();
        
        
        
         
         

	}

}
