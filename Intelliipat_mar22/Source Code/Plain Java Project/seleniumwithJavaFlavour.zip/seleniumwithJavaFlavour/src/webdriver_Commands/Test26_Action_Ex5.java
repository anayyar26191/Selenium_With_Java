package webdriver_Commands;


import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class Test26_Action_Ex5 {

	public static void main(String[] args) throws InterruptedException {
	//Launch Chrome Browser 
		System.setProperty("webdriver.chrome.driver","D:\\March22nd_2020\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		
		driver.get("http://www.google.com");
		
		Thread.sleep(7000);
		WebElement e=driver.findElement(By.xpath("//input[@name='q']"));
		Actions a=new Actions(driver);
		//send Text into textbox
	   a.click(e).sendKeys("bhanu").build().perform();
		Thread.sleep(5000);
		//step down
		a.click(e).sendKeys(Keys.DOWN).build().perform();
		
		Thread.sleep(5000);
		//step down
		a.click(e).sendKeys(Keys.DOWN).build().perform();
		
		Thread.sleep(5000);
		a.click(e).sendKeys(Keys.ENTER).build().perform();
		Thread.sleep(5000);
		driver.close();
		
		
	
	}

}
