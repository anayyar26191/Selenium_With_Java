package webdriver_Commands;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Test23_Way2smsLogin {

	public static void main(String[] args) throws InterruptedException {
		// Launch Firefox Browser
		 System.setProperty("webdriver.chrome.driver","D:\\March22nd_2020\\chromedriver.exe");
		 WebDriver driver=new ChromeDriver();
		 
		 //Goto Test URL 
		 driver.get("https://www.sms4india.com/");
		 
		 //WaitTime
         Thread.sleep(5000);
         driver.manage().window().maximize();
         
         //Enter Mobile number
         driver.findElement(By.xpath("(//input[@name='mobileNo'])[1]")).sendKeys("7003730934");
         Thread.sleep(5000);
         //Enter Password
         driver.findElement(By.xpath("(//input[@id='password'])[1]")).sendKeys("7003730934");
         Thread.sleep(5000);
         //Click Login
         driver.findElement(By.xpath("(//button)[5]")).click(); 
         Thread.sleep(5000);
         System.out.println("Login Sucess");
         //close browser
         driver.close();
        
        
        
         
         

	}

}
