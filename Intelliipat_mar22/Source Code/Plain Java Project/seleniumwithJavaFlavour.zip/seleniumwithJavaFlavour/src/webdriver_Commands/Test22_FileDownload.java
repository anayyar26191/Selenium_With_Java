package webdriver_Commands;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Test22_FileDownload {

	public static void main(String[] args) throws InterruptedException, AWTException {
		//Launch Chrome Browser
		System.setProperty("webdriver.gecko.driver","D:\\March22nd_2020\\geckodriver.exe");
		WebDriver driver=new FirefoxDriver();
		//Pass the Test URL
		driver.get("https://www.selenium.dev/downloads/");
		Thread.sleep(5000);
		//Click on Download
		driver.findElement(By.xpath("//div[@class='container basic dark-background']/table[1]/tbody[1]/tr[2]/td[6]/a[1]")).click();
		Thread.sleep(5000);
		//Handling File Download using JavaRobot
		Robot r=new Robot();
		/*r.keyPress(KeyEvent.VK_DOWN);
		r.keyRelease(KeyEvent.VK_DOWN);*/
		r.keyPress(KeyEvent.VK_ENTER);
		r.keyRelease(KeyEvent.VK_ENTER);
		
		//Download Time
		Thread.sleep(10000);
		driver.close();
		
	}

}
