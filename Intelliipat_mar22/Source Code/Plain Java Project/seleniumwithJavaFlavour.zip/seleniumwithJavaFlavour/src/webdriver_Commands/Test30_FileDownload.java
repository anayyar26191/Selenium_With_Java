package webdriver_Commands;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Test30_FileDownload {

	public static void main(String[] args) throws InterruptedException, AWTException {
		//Launch Chrome Browser
		System.setProperty("webdriver.gecko.driver","D:\\March22nd_2020\\geckodriver.exe");
		WebDriver driver=new FirefoxDriver();
		//Pass the Test URL
		driver.get("https://launchpad.net/sikuli");
		Thread.sleep(5000);
		//Click on Download
		driver.findElement(By.xpath("//a[text()='sikulixide-2.0.4.jar']")).click();
		Thread.sleep(5000);
		//Handling File Download using JavaRobot
		Robot r=new Robot();
		r.keyPress(KeyEvent.VK_LEFT);
		r.keyRelease(KeyEvent.VK_LEFT);
		r.keyPress(KeyEvent.VK_ENTER);
		r.keyRelease(KeyEvent.VK_ENTER);
		
		//Download Time
		Thread.sleep(10000);
		driver.close();
		
	}

}
