package webdriver_Commands;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Test21_Gmail_FileUpload {

	public static void main(String[] args) throws InterruptedException, AWTException {
		//Launch Chrome Browser
		System.setProperty("webdriver.chrome.driver","D:\\March22nd_2020\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		//Pass the Test URL
		driver.get("https://www.gmail.com");
		
		Thread.sleep(5000);
		
	
//Fill User name TextBox		
				driver.findElement(By.xpath("//input[@id='identifierId']")).sendKeys("selenium6river@gmail.com");
				Thread.sleep(5000);
//Click on Next Button
		driver.findElement(By.xpath("//span[text()='Next']")).click();
		Thread.sleep(6000);
//Fill Password  TextBox
		driver.findElement(By.xpath("//input[@name='password']")).sendKeys("JavaPythonRocks");
		Thread.sleep(7000);
//Click on Next Button
		driver.findElement(By.xpath("//span[text()='Next']")).click();
		Thread.sleep(10000);
//Click on Compose
		driver.findElement(By.xpath("//div[text()='Compose']")).click();
		Thread.sleep(12000);
//Fill To address Textbox
		driver.findElement(By.name("to")).sendKeys("selenium6river@gmail.com");
		//driver.findElement(By.xpath("//textarea[@name='to']")).sendKeys("selenium6river@gmail.com");
		Thread.sleep(7000);
//Fill Subject TextBox
		driver.findElement(By.xpath("//input[@aria-label='Subject']")).sendKeys("Wishes");
		//driver.findElement(By.xpath("//input[@name='subjectbox']")).sendKeys("Wishes");
		Thread.sleep(7000);
//Fill Message Body
		driver.findElement(By.xpath("//div[@aria-label='Message Body']")).sendKeys("Hi,",Keys.ENTER,"Please place your Order");
		Thread.sleep(7000);
//Handling File Uplaod 		
	//Add Attachment
			driver.findElement(By.xpath("//div[@data-tooltip='Attach files']")).click();
			
	//Put Data into Clipboard
			StringSelection s=new StringSelection("C:\\Users\\Public\\Pictures\\Sample Pictures\\Tulips.jpg");
	//Send	the Data from Clipboard to Screen
			Toolkit.getDefaultToolkit().getSystemClipboard().setContents(s, null);
			
			//Perform Paste Operation CONTROL  V and ENTER 
			
//Using Java Robot
			//import the Robot class from awt package
			Robot r=new Robot();
			//Paste
			r.keyPress(KeyEvent.VK_CONTROL);
			r.keyPress(KeyEvent.VK_V);
			r.keyRelease(KeyEvent.VK_V);
			r.keyRelease(KeyEvent.VK_CONTROL);
			//ENTER
			r.keyPress(KeyEvent.VK_ENTER);
			r.keyRelease(KeyEvent.VK_ENTER);
			Thread.sleep(12000);
//click on send button
			driver.findElement(By.xpath("//div[text()='Send']")).click();
			Thread.sleep(6000);
//Logout Click on account
			driver.findElement(By.xpath("//a[contains(@aria-label,'Google Account:')]")).click();
			Thread.sleep(5000);
			driver.findElement(By.xpath("//a[text()='Sign out']")).click();
			Thread.sleep(5000);
//close the browser
		driver.close();
		
	}

}
