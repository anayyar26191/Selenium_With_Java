//1 Documentation Section Single Line Comment 
  	/*-Software
	-Type of Softwares
	-STE vs SDET
	-Why When Automation
	-SDLC
	-Types of Testing
	-SELENIUM HISTORY--------------
	-TEST ENVIRONMENT SETUP
	-Selenium History
	-Selenium Introduction
	-First Test Script
	-Overview of Elements
	-Browser Automation*/




//2 Package declaration Statement Ex: package webdriverScripts 

package demoJavaExamples;



/*3.Import Statements 
We import built in and  User defined libraries using import keyword
Ex:  import io.Console;
import java.lang.*;
import seleniumwithJavaFlavour.demoJavaExamples.*;
import ---Is is a Java Keywoprd to import libraries
java -- built in project name
seleniumwithJavaFlavour--user created project name
lang-- built in  package name
demojavaExamples---use created package name
 */



/* 4  public --Access Modifiers
class ---java keyword to declare a class
First --user created Class*/

public class First {
	
	
	
	
	
	
//Create a Method(User Defined)
	  // method with return type
	
public int multiply(int a,int b,int c)
{
	int result=a*b*c;
	return result;

}

//Create a Method(User Defined)
// method with out return type
public void comparison()
{
	int p,q; //Variales Declaration
	p=10;q=20; //Initialization
}

	
	
	
/*	
5 public --Access Modifier 
  static --Non -Access Modifier ( use main method without invoking any object)
  void ---Returns nothing 
  main ---method name
  */
	public static void main(String[] args) {
		
		//This is a Sample Program
		int a,b,c;   //Variables Declaration 
		a=10; b=20; c=30;  //Initialization
		
		int d=40; //Both Variable Declaration and Initialization of Value/Data
		
		final int money=100; //Constant Declaration
		
		
/*6.Decalrations
 * We can Declare Variables and Constants 
 * Other Statements
 * System.out.println(":Autoamtion");
 * System is a  Pre Defined Class
 * out --object
 * println() ---method()
 * "Automation"  -Message*/		
		System.out.println("Autoamtion");
		
	//Conditional Block
		if(a>b)
		{
			System.out.println("A is a Big Number");
		}
		else
		{
			System.out.println("B is a Big Number");
		}
		//Loop block
		
		for(int i=1; i<=10; i++)
		{
	    System.out.println("BhanuSai");
		System.out.println(i);
		
		}
		
		
		
	//Create Objectand access Methods
		First sai=new First();
	   int x=sai.multiply(2, 5, 4);
	   System.out.println(x);
	   
	   
		
		
		
		
		
		
		
		



	}

}
