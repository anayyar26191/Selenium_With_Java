package topic_BeforeAfterGroups;

import org.testng.annotations.AfterGroups;
import org.testng.annotations.BeforeGroups;
import org.testng.annotations.Test;

public class BeforeAfterGroups {

//For Security
    @BeforeGroups("security")	
	public void setupSecurity()
	
	{
		System.out.println("setupSecurity()"); 
		
	}
    @AfterGroups("security")	
	public void teardownSecurity()
	
	{
		System.out.println("teardownSecurity()"); 
		
	}
  //For Database
    @BeforeGroups("database")	
	public void setupDatabse()
	
	{
		System.out.println("setupDatabse()"); 
		
	}
    @AfterGroups("database")	
	public void teardownDatabse()
	
	{
		System.out.println("teardownDatabse()"); 
		
	}   
    
    
    //For UI
    @BeforeGroups("ui")	
	public void setupUI()
	
	{
		System.out.println("setupUI()"); 
		
	}
    @AfterGroups("ui")	
	public void teardownUI()
	
	{
		System.out.println("teardownUI()"); 
		
	}   
    
      
 //UI Test Cases

	@Test(groups="ui")
	public void openFileDialog()
	{
		System.out.println("openFileDialog()");
	}
	
	
	@Test(groups="ui")
	public void openconformationDialog()
	{
		System.out.println("openconformationDialog()");
	}
	
	
//Databse Test Cases 

	@Test(groups="database")
	public void testInsert()
	{
		System.out.println("testInsert()");
	}
	
	@Test(groups="database")
	public void testDelete()
	{
		System.out.println("testDelete()");
	}

	@Test(groups="database")
	public void testUpdate()
	{
		System.out.println("testUpdate()");
	}
	
//Security TestCases
	@Test(groups="security")
	public void accesHomePage()
	{
		System.out.println("accesHomePage()");
	}
	
	
	@Test(groups="security")
	public void accesAdminPage()
	{
		System.out.println("accesAdminPage()");
	}
    
    
    
	
}
