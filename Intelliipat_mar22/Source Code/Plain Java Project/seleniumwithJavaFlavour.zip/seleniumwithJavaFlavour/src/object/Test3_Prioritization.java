package object;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

public class Test3_Prioritization {
	
public WebDriver driver;	
/*	TestScenario-3
	------------
	Lauch Chrome Browser
	Goto Test URL https://www.facebook.com
	Wait for 5  sec
	Verify Title of Page 
	Close Browser
	=========
	Teast data
	---------
	https://www.bhanusaii.wordpress.com
	Expected Title
	Facebook � log in or sign up
	Actual Title
*/	@Test(priority=600)
public void verifyFacebookTitle()
{
//Verify Title of Page 		
	String atitle=driver.getTitle();
	System.out.println(atitle);
	String ExpTtitle="Sai-Facebook � log in or sign up";



	
Assert.assertEquals(atitle, ExpTtitle);	
	
}
	
	@Test(priority=100)
	public void launch()
	{
//Lauch Chrome Browser
		System.setProperty("webdriver.chrome.driver","D:\\March22nd_2020\\chromedriver.exe");
		 driver=new ChromeDriver();
		
	}
	
	
	
	@Test(priority=200)
	public void passURL()
	{
	
//	Goto Test URL https://www.facebook.com
		driver.get("https://www.facebook.com");
	}
	
	@Test(priority=400)
	public void waitTime()
	{
	
//	Wait for 5  sec
		 driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS);
		 
	}
	
	   @Test(priority=900)
		public void teartdown()
		{
//		Close Browser
	     driver.close();		
		}
		

	
 
	
}
