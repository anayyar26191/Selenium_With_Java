package object;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LoginPage {
	
	
WebDriver driver;

//Specify the Object locators
By UserNameField=By.xpath("//input[@id='identifierId']");

By MovetoNext=By.xpath("//span[text()='Next']");	

By PwdField=By.xpath("//input[@name='password']");
	
By compose=By.xpath("//span[text()='compose']");



public LoginPage(WebDriver driver)
{
	this.driver=driver;
}

//Create Individual methods

public void type_UserName(String uname)
{
	driver.findElement(UserNameField).sendKeys(uname);
}

public void click_Next()
{
	driver.findElement(MovetoNext).click();
}


public void type_password(String password)
{
	driver.findElement(PwdField).sendKeys(password);
}

public void click_Compose()
{
	driver.findElement(compose).click();
}
}
