package topic_Adv_annotations;

import org.testng.annotations.Test;

public class TestSecurity {
	
	
	@Test(groups="security")
	public void accesHomePage()
	{
		System.out.println("accesHomePage()");
	}
	
	
	@Test(groups="security")
	public void accesAdminPage()
	{
		System.out.println("accesAdminPage()");
	}
	
}
