package topic_Adv_annotations;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class TestUI {
	
	@BeforeTest
	public void beforeTest()
	{
		System.out.println("@BeforeTest");
	}

	@AfterTest
	public void afterTest()
	{
		System.out.println("@AfterTest");
	}
	
	@Test(groups="ui")
	public void openFileDialog()
	{
		System.out.println("openFileDialog()");
	}
	
	
	@Test(groups="ui")
	public void openconformationDialog()
	{
		System.out.println("openFileDialog()");
	}
	
	
	

}
