package topic_PageObjectModel;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class TestCase2 {

	public static void main(String[] args) throws InterruptedException {
		//Launch Chrome Browser
				System.setProperty("webdriver.chrome.driver","D:\\March22nd_2020\\chromedriver.exe");
				WebDriver driver=new ChromeDriver();
				//Pass the Test URL
				driver.get("https://www.gmail.com");
				Thread.sleep(5000);
				LoginPage login=new LoginPage(driver);
				
				Thread.sleep(5000);
				//Fill UserName TextBox
				login.type_UserName("selenium6river@gmail.com");
				Thread.sleep(5000);
				//Click on Next Button
				login.click_Next();	
				Thread.sleep(5000);
				//Fill Password TextBox
				login.type_password("What15What");
				Thread.sleep(5000);
				login.click_Next();
				Thread.sleep(5000);
				
				String acturl=driver.getCurrentUrl();
				System.out.println(acturl);
				
				//Expexted URL https://mail.google.com/mail/u/0/#inbox
			
				if(acturl.contains("https://mail.google.com/mail/u"))
				{
					System.out.println("Gmail Login Sucess-Test Passed");
				}
				else
				{
					System.out.println("Gmail Login Failed-Test Failed");
				}
				driver.close();
	}

}
