package topic_TestNG_dataprovider;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import jxl.Cell;
import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;


public class DatadrivernWay2sms {
	public WebDriver driver;

	
	@Test(dataProvider="testData")
	public void loginWays2sms(String uuname,String ppasswd) throws InterruptedException
	{
		
    	// Launch chrome Browser
		 System.setProperty("webdriver.chrome.driver","D:\\March22nd_2020\\chromedriver.exe");
		  driver=new ChromeDriver();
		 
		 //Goto Test URL 
		 driver.get("https://www.sms4india.com/");
		 
		 //WaitTime
        Thread.sleep(5000);
        driver.manage().window().maximize();
        
        //Enter Mobile number
        driver.findElement(By.xpath("(//input[@name='mobileNo'])[1]")).sendKeys(uuname);
        Thread.sleep(5000);
        //Enter Password
        driver.findElement(By.xpath("(//input[@id='password'])[1]")).sendKeys(ppasswd);
        Thread.sleep(5000);
        //Click Login
        driver.findElement(By.xpath("(//button)[5]")).click(); 
        Thread.sleep(5000);
        
       //Verification Point
        String ExpURL="https://www.sms4india.com/send-sms";
        String ActURL=driver.getCurrentUrl();
        System.out.println(ActURL);
        /*if(ExpURL.equals(ActURL))
        {
        	  System.out.println("Login Sucess-Test Passed");
        	 
        }
        else
        {
        	 System.out.println("Login Faield-Test Failed");
       	
        }
        */
        Assert.assertEquals(ActURL, ExpURL);
    }
		
	
	
	
	@AfterMethod
	public void getTestResult(ITestResult testResult)
	{
		System.out.println("TestCase Name :"+testResult.getName());
		System.out.println("Test Case Result :"+testResult.getStatus());  //Results Integer value 1--Test Passed 2---Test Failed
		int status=testResult.getStatus();
		if(status==1)
		{
			driver.close();
		}
		else
		{
			//Take Screenshot
			File outfile=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
			try {
				FileUtils.copyFile(outfile,new File("D:\\March22nd_2020\\seleniumwithJavaFlavour\\src\\topic_TestNG_dataprovider"+testResult.getParameters()[0]+"Defect.jpeg"));
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			driver.close();
		}
		
	}
	

	
	
	
	
	
	@DataProvider(name="testData")
	public Object[][] readExcel() throws BiffException, IOException 
	{
		//Open the Excel for read and write,which is available under same package 
		
		File f=new File("D:\\March22nd_2020\\seleniumwithJavaFlavour\\src\\topic_TestNG_dataprovider\\TestData.xls");
		Workbook w=Workbook.getWorkbook(f);
		Sheet s=w.getSheet(0);
		int noofRows=s.getRows();
		System.out.println(s.getRows());
		
		int noofColu=s.getColumns();
		System.out.println(s.getColumns());
		
		String inputData[][]=new String[noofRows-1][noofColu];
		
		int count=0;
		for(int i=1;i<noofRows;i++)
		{
			for(int j=0;j<noofColu;j++)
			{

				Cell c=s.getCell(j,i);
				System.out.println(s.getCell(j,i));
				
				System.out.println(c.getContents());
				
				inputData[count][j]=c.getContents();
			}
			count++;
		}
		return inputData;

			
	}
	
	

	
}
