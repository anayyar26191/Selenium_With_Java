package topic_TestNG_PageObjectmodel;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Login_PageObjects {
	
	WebDriver driver;
	//Specify the Object/Element Locators
	
	By UserNameField=By.xpath("//input[@name='identifier']");
	By MovetoNext=By.xpath("//span[text()='Next']");
	By PwdField=By.xpath("//input[@name='password']");
	By Err_msg_Uname=By.xpath("//input[@id='identifierId']/following::*[6]");
	
	
/*Non-POM Approach			
	//driver.findElement(By.xpath("//input[@name='identifier']")).sendKeys("kumardummy856@gmail.com");
	//driver.findElement(By.xpath("//span[text()='Next']")).click();
	//driver.findElement(By.xpath("//input[@name='password']")).sendKeys("kumar123@");
*/	
	
	public Login_PageObjects(WebDriver driver)
	{
		this.driver=driver;
		
	}
	
	
	public void type_UserName(String uname)
	{
		driver.findElement(UserNameField).sendKeys(uname);
	}
	
	
	public void click_Next()
	{
		driver.findElement(MovetoNext).click();
	}
	

	public void type_password(String password)
	{
		driver.findElement(PwdField).sendKeys(password);
	}
	
	
	
	
	
	public String captureErr()
	{
		return driver.findElement(Err_msg_Uname).getText();
	}
	
	

}
