package topic_TestNG_PageObjectmodel;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class TestCase1 {
	  static Login_PageObjects login;
	 	 static WebDriver driver;
	 	
@Test(priority=0)
	//public static void main(String[] args) throws InterruptedException {
public static void myTest() throws InterruptedException
{
	//Launch Chrome Browser
	System.setProperty("webdriver.chrome.driver","D:\\Intellipaat_Nov24th_2019\\chromedriver.exe");
//To Open Browser		
 driver=new ChromeDriver();
	
//Navigate to Test URL
	
	driver.get("https://www.gmail.com");
	login=new Login_PageObjects(driver);
		
				Thread.sleep(5000);
				//Login_PageObjects login=new Login_PageObjects(driver);
				Thread.sleep(5000);
				login.type_UserName("kumardummy856@gmail.com");
				Thread.sleep(5000);
				login.click_Next();
				Thread.sleep(5000);
}



@Test(priority=1)

public static void vpoint() throws InterruptedException
{
	login=new Login_PageObjects(driver);
				/*login.type_password("kumar_1986@");
				Thread.sleep(5000);
				login.click_Next();
				Thread.sleep(8000);*/
				
				String errmeggage=login.captureErr();
				
				System.out.println(errmeggage);
				
				if(errmeggage.contains("Couldn't find your Google Account"))
				{
					System.out.println("Test Passed");
				}
				else
				{
					System.out.println("Test Failed");
				}
				
				driver.close();
	}

}
